# HausaSmart v1.3.1 — Render Ready

An shirya wannan version musamman domin deployment a Render daga GitHub.

## Render settings
- Service type: Web Service
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/api/health`

## Secrets
A Render Environment, ƙara:
- `OPENAI_API_KEY` = API key ɗinka
- `OPENAI_MODEL` = `gpt-5.6`

**Kada ka saka API key cikin GitHub ko `index.html`.**

## Muhimmi
Render web services suna buƙatar app ya saurari `0.0.0.0`; server.js na wannan version ya riga ya yi hakan.
