import 'dotenv/config';
import express from 'express';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const port = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too_many_requests', reply: 'An yi yawan requests. Ka jira kaɗan sannan ka sake gwadawa.' }
});

app.use('/api/', apiLimiter);
app.use(express.static(path.join(__dirname, 'public')));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const SYSTEM_PROMPT = `
Kai HausaSmart AI ne, mataimakin dijital ga masu amfani da Hausa da English.
Ka fi son Hausa mai sauƙi, bayyananniya, da girmamawa idan mai amfani ya rubuta Hausa.
Ka taimaka musamman wajen CV, neman aiki, koyon skills, fassara, social media, da shirye-shiryen sana'a.
Kada ka ƙirƙiri wani aiki, albashi, kamfani ko link a matsayin tabbataccen abu idan ba ka da tabbaci.
Kada ka nemi password, OTP, PIN, API key ko wasu sirrin shiga.
Idan mai amfani ya nemi shawara mai hatsari ko doka/likita, ka yi taka-tsantsan kuma ka ba da shawarar kwararre idan ya dace.
`;

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    aiConfigured: Boolean(process.env.OPENAI_API_KEY),
    model: process.env.OPENAI_MODEL || 'gpt-5.6'
  });
});

app.post('/api/ai', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  if (!message) return res.status(400).json({ error: 'message_required' });
  if (message.length > 8000) return res.status(413).json({ error: 'message_too_long' });

  if (!client) {
    return res.status(503).json({
      configured: false,
      reply: 'HausaSmart AI bai haɗu da API key ba tukuna. Ka sa OPENAI_API_KEY a server sannan ka sake kunna app.'
    });
  }

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.6',
      instructions: SYSTEM_PROMPT,
      input: message,
      store: false
    });

    res.json({
      configured: true,
      reply: response.output_text || 'Yi hakuri, ban samu amsa ba.'
    });
  } catch (error) {
    console.error('HausaSmart AI error:', error?.message || error);
    res.status(502).json({
      configured: true,
      reply: 'Yi hakuri, an samu matsala wajen haɗa AI. Ka sake gwadawa.'
    });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, '0.0.0.0', () => {
  console.log(`HausaSmart v1.3.1 listening on port ${port}`);
});
